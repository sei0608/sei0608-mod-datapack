execute positioned ~ ~1 ~ run tp @s ~ ~1 ~
function minecraft:test