execute on origin store result score @s diamond run clear @s diamond 0
tag @s add inc_enchant.lightning.arrow