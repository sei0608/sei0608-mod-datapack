scoreboard players add @s shadow 1

execute if block ~ ~2 ~ #leaves run effect give @s[scores={shadow=20}] instant_health 1 0 true
execute if block ~ ~3 ~ #leaves run effect give @s[scores={shadow=20}] instant_health 1 0 true
execute if block ~ ~4 ~ #leaves run effect give @s[scores={shadow=20}] instant_health 1 0 true
execute if block ~ ~5 ~ #leaves run effect give @s[scores={shadow=20}] instant_health 1 0 true
execute if block ~ ~6 ~ #leaves run effect give @s[scores={shadow=20}] instant_health 1 0 true


effect clear @s[scores={shadow=25..}] instant_health
scoreboard players reset @s[scores={shadow=25..}] shadow