execute as @s at @s on attacker run tp @s ~ ~ ~
