execute on origin run tp @s ~ ~0.5 ~
particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.1 30
playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 1 1
kill @s[type=arrow]