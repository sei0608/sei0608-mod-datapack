effect give @s weakness 5 0 false
particle trial_omen ~ ~ ~ 0.5 0.5 0.5 0 10