# 記憶していた固有タグを持つ2体（攻撃者と被害者）を探し出す
$tag @e[tag=swap_id_$(id),limit=1,sort=arbitrary] add swap_A
$tag @e[tag=swap_id_$(id),tag=!swap_A,limit=1,sort=arbitrary] add swap_B

# 2体ともまだ生存・存在していれば、入れ替えを実行
execute if entity @e[tag=swap_A] if entity @e[tag=swap_B] run function inc_enchant:rimokon/illusion/execute_swap

# 今回使った固有タグと一時タグを消去して綺麗にする
$tag @e remove swap_id_$(id)
tag @e remove swap_A
tag @e remove swap_B