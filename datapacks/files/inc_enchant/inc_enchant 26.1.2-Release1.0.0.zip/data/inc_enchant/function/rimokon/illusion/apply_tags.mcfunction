# $(id) を展開し、今回の攻撃専用のタグ（例: swap_id_15）を両者に付与
$tag @e[tag=swap_victim_temp] add swap_id_$(id)
$tag @e[tag=swap_attacker_temp] add swap_id_$(id)

# タイマー用マーカーを召喚し、専用タグのIDを記憶させる
$summon marker ~ ~ ~ {Tags:["swap_marker", "swap_new_marker"], data:{swap_id:$(id)}}

# 召喚したばかりのマーカーに5秒(100)のタイマーをセット
scoreboard players set @e[type=marker,tag=swap_new_marker] swap_timer 80
tag @e[type=marker,tag=swap_new_marker] remove swap_new_marker