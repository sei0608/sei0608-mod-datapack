# 攻撃ごとに一意のIDを生成し、ストレージに保存（マクロ用）
scoreboard players add #current global_vars 1
execute store result storage swap:data id int 1 run scoreboard players get #current global_vars

# 対象ペアを特定するための一時タグ
tag @s add swap_victim_temp
execute on attacker run tag @s add swap_attacker_temp

# マクロを実行して固有タグを付与
function inc_enchant:rimokon/illusion/apply_tags with storage swap:data

# 一時タグを消去
tag @s remove swap_victim_temp
execute on attacker run tag @s remove swap_attacker_temp