# Aの位置に基準となるアンカー（マーカー）を置く
execute as @e[tag=swap_A] at @s run summon marker ~ ~ ~ {Tags:["swap_anchor"]}

# AをBの位置へテレポート
execute as @e[tag=swap_A] at @s run tp @s @e[tag=swap_B,limit=1]

# Bをアンカー（Aの元の位置）へテレポート
execute as @e[tag=swap_B] at @s run tp @s @e[tag=swap_anchor,limit=1]

# アンカーを削除
kill @e[type=marker,tag=swap_anchor]