
execute unless score @s bounce matches ..2147483647 run scoreboard players set @s bounce 0

execute as @s at @s if block ~ ~0.1 ~ air positioned ~ ~0.1 ~ run tp @s[scores={bounce=..30}] ~ ~0.1 ~
scoreboard players add @s bounce 1

execute if score @s bounce matches ..30 run function inc_enchant:rimokon/bounce
scoreboard players reset @s[scores={bounce=30..}] bounce
