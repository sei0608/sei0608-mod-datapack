execute as @s unless entity @s[tag=inc_enchant.lightning.arrow] run return fail


summon spawner_minecart ~ ~ ~ {Tags:[inc_enchant],RequiredPlayerRange:300,MaxNearbyEntities:5000,Delay:5,SpawnCount:1,SpawnData:{entity:{id:"lightning_bolt"}}}

execute store result entity @n[type=spawner_minecart] SpawnCount short 1 on origin run scoreboard players get @s diamond

execute store result entity @n[type=spawner_minecart] SpawnRange short 0.4 on origin run scoreboard players get @s diamond

execute on origin run scoreboard players reset @s diamond
kill @e[type=spawner_minecart,nbt={SpawnCount:0s}]
kill @s[type=arrow]