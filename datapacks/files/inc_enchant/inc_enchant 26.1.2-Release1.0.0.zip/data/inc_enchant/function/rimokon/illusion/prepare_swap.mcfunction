# マーカーが記憶していた自身のIDをストレージに読み出す
data modify storage swap:data id set from entity @s data.swap_id

# IDを渡して入れ替えマクロを実行
function inc_enchant:rimokon/illusion/do_swap with storage swap:data

# 役割を終えたマーカーを削除
kill @s