execute unless entity @s[type=arrow] run return fail

place template inc_enchant:goldentree ~-2 ~1 ~-2
kill @s[type=arrow]
fillbiome ~2 ~1 ~2 ~-2 ~5 ~-2 inc_enchant:golden_tree