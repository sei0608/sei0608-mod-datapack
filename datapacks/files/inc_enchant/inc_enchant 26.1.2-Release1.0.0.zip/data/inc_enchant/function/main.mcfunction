execute as @e[type=marker,tag=golden_tree] at @s if block ~ ~ ~ air run loot spawn ~ ~ ~ loot inc_enchant:golden_tree
execute as @e[type=marker,tag=golden_tree] at @s if block ~ ~ ~ air run kill @s

scoreboard players remove @a[scores={heal=1..}] heal 1
effect clear @a[scores={heal=0}] regeneration
scoreboard players reset @a[scores={heal=0}] heal

# タイマーを1ずつ減らす
execute as @e[type=marker,tag=swap_marker,scores={swap_timer=1..}] run scoreboard players remove @s swap_timer 1

# 0になったマーカーに、入れ替え準備を実行させる
execute as @e[type=marker,tag=swap_marker,scores={swap_timer=0}] at @s run function inc_enchant:rimokon/illusion/prepare_swap

#execute as @e[type=minecraft:arrow,nbt={inGround:1b},nbt={weapon:{components:{"minecraft:enchantments":{"inc_enchant:rimokon/teleport_arrow":1}}}}] at @s run function inc_enchant:rimokon/teleport_arrow

execute as @e[type=spawner_minecart] at @s store result score @s spawner run data get entity @s Delay 1
kill @e[type=spawner_minecart,tag=inc_enchant,scores={spawner=20..}]

scoreboard players add @e[scores={jump=0..}] jump 1
execute as @e[scores={jump=200..}] run attribute @s jump_strength base reset
scoreboard players reset @e[scores={jump=200..}] jump
scoreboard players add @e[scores={totem.time=1..}] totem.time 1