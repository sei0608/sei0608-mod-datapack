execute unless items entity @s armor.* #minecraft:enchantable/armor run return fail
execute store result score @s fail run random value 1..10
execute unless score @s fail matches 1..3 run return fail
execute store result score @s borrow_arrow run random value 1..4




function inc_enchant:borrow_armor_attacker