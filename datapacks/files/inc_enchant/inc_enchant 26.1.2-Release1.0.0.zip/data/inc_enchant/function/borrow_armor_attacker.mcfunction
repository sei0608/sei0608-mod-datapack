execute on attacker run tag @s add borrow_armor
execute if score @s borrow_arrow matches 1 if items entity @s armor.head #enchantable/armor run item replace entity @p[tag=borrow_armor] armor.head from entity @s armor.head
execute if score @s borrow_arrow matches 2 if items entity @s armor.chest #enchantable/armor run item replace entity @p[tag=borrow_armor] armor.chest from entity @s armor.chest
execute if score @s borrow_arrow matches 3 if items entity @s armor.legs #enchantable/armor run item replace entity @p[tag=borrow_armor] armor.legs from entity @s armor.legs
execute if score @s borrow_arrow matches 4 if items entity @s armor.feet #enchantable/armor run item replace entity @p[tag=borrow_armor] armor.feet from entity @s armor.feet
tag @a remove borrow_armor