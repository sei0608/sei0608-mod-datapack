
execute positioned ~ ~1 ~ summon tnt run data modify entity @s Motion set from entity @n[type=arrow] Motion