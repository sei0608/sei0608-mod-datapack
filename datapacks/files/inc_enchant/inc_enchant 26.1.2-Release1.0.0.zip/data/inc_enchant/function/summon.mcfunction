summon marker ~ ~2 ~ {Tags:["golden_tree"]}
summon marker ~ ~3 ~ {Tags:["golden_tree"]}