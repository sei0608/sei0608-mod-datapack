execute store result score @s atack run attribute @s attack_damage modifier value get base_attack_damage 100
scoreboard players add @s atack 10
item modify entity @s weapon.mainhand inc_enchant:atack
#scoreboard players reset @s atack
