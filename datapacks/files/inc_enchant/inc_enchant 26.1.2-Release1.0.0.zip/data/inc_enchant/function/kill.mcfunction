summon marker ~ ~ ~ {CustomName:"死式「屍」"}
damage @s 10000000 player_attack by @n[name="死式「屍」"]
kill @e[name="死式「屍」"]