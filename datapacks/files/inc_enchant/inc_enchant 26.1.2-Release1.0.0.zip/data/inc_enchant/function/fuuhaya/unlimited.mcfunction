execute if entity @s[nbt={Health:0.0f}] run execute on attacker run xp add @s 1 levels
execute if entity @s[nbt={Health:0.0f}] run execute on attacker at @s run \
            particle minecraft:trial_spawner_detection ~ ~ ~ 0.5 0 0.5 0 50

