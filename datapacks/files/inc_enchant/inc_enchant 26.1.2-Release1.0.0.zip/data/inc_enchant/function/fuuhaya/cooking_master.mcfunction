# 食べ物
execute if items entity @s inventory.* mutton run give @s cooked_mutton 1
execute if items entity @s inventory.* mutton run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* mutton run title @s actionbar {"text":"羊肉を焼きました","color":"gold"}
execute if items entity @s inventory.* mutton run clear @s mutton 1
execute if items entity @s hotbar.* mutton run give @s cooked_mutton 1
execute if items entity @s hotbar.* mutton run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* mutton run title @s actionbar {"text":"羊肉を焼きました","color":"gold"}
execute if items entity @s hotbar.* mutton run clear @s mutton 1
execute if items entity @s inventory.* beef run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* beef run title @s actionbar {"text":"牛肉を焼きました","color":"gold"}
execute if items entity @s inventory.* beef run clear @s beef 1
execute if items entity @s hotbar.* beef run give @s cooked_beef 1
execute if items entity @s hotbar.* beef run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* beef run title @s actionbar {"text":"牛肉を焼きました","color":"gold"}
execute if items entity @s hotbar.* beef run clear @s beef 1
execute if items entity @s inventory.* chicken run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* chicken run title @s actionbar {"text":"鶏肉を焼きました","color":"gold"}
execute if items entity @s inventory.* chicken run clear @s chicken 1
execute if items entity @s hotbar.* chicken run give @s cooked_chicken 1
execute if items entity @s hotbar.* chicken run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* chicken run title @s actionbar {"text":"鶏肉を焼きました","color":"gold"}
execute if items entity @s hotbar.* chicken run clear @s chicken 1
execute if items entity @s inventory.* cod run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* cod run title @s actionbar {"text":"タラを焼きました","color":"gold"}
execute if items entity @s inventory.* cod run clear @s cod 1
execute if items entity @s hotbar.* cod run give @s cooked_cod 1
execute if items entity @s hotbar.* cod run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* cod run title @s actionbar {"text":"タラを焼きました","color":"gold"}
execute if items entity @s hotbar.* cod run clear @s cod 1
execute if items entity @s inventory.* porkchop run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* porkchop run title @s actionbar {"text":"豚肉を焼きました","color":"gold"}
execute if items entity @s inventory.* porkchop run clear @s porkchop 1
execute if items entity @s hotbar.* porkchop run give @s cooked_porkchop 1
execute if items entity @s hotbar.* porkchop run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* porkchop run title @s actionbar {"text":"豚肉を焼きました","color":"gold"}
execute if items entity @s hotbar.* porkchop run clear @s porkchop 1
execute if items entity @s inventory.* salmon run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* salmon run title @s actionbar {"text":"サケを焼きました","color":"gold"}
execute if items entity @s inventory.* salmon run clear @s salmon 1
execute if items entity @s hotbar.* salmon run give @s cooked_salmon 1
execute if items entity @s hotbar.* salmon run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* salmon run title @s actionbar {"text":"サケを焼きました","color":"gold"}
execute if items entity @s hotbar.* salmon run clear @s salmon 1
execute if items entity @s inventory.* potato run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* potato run title @s actionbar {"text":"ジャガイモを焼きました","color":"gold"}
execute if items entity @s inventory.* potato run clear @s potato 1
execute if items entity @s hotbar.* potato run give @s baked_potato 1
execute if items entity @s hotbar.* potato run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* potato run title @s actionbar {"text":"ジャガイモを焼きました","color":"gold"}
execute if items entity @s hotbar.* potato run clear @s potato 1
execute if items entity @s inventory.* chorus_fruit run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* chorus_fruit run title @s actionbar {"text":"コーラスフルーツを焼きました","color":"gold"}
execute if items entity @s inventory.* chorus_fruit run clear @s chorus_fruit 1
execute if items entity @s hotbar.* chorus_fruit run give @s popped_chorus_fruit 1
execute if items entity @s hotbar.* chorus_fruit run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* chorus_fruit run title @s actionbar {"text":"コーラスフルーツを焼きました","color":"gold"}
execute if items entity @s hotbar.* chorus_fruit run clear @s chorus_fruit 1
execute if items entity @s inventory.* kelp run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* kelp run title @s actionbar {"text":"昆布を焼きました","color":"gold"}
execute if items entity @s inventory.* kelp run clear @s kelp 1
execute if items entity @s hotbar.* kelp run give @s dried_kelp 1
execute if items entity @s hotbar.* kelp run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* kelp run title @s actionbar {"text":"昆布を焼きました","color":"gold"}
execute if items entity @s hotbar.* kelp run clear @s kelp 1
execute if items entity @s inventory.* cobblestone run give @s stone 1
execute if items entity @s inventory.* cobblestone run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* cobblestone run title @s actionbar {"text":"丸石を焼きました","color":"gold"}
execute if items entity @s inventory.* cobblestone run clear @s cobblestone 1
execute if items entity @s inventory.* deepslate run give @s deepslate 1
execute if items entity @s inventory.* deepslate run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* deepslate run title @s actionbar {"text":"深層岩を焼きました","color":"gold"}
execute if items entity @s inventory.* deepslate run clear @s deepslate 1
execute if items entity @s hotbar.* deepslate run give @s deepslate 1
execute if items entity @s hotbar.* deepslate run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* deepslate run title @s actionbar {"text":"深層岩を焼きました","color":"gold"}
execute if items entity @s hotbar.* deepslate run clear @s deepslate 1
execute if items entity @s inventory.* iron_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* iron_ore run title @s actionbar {"text":"鉄鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* iron_ore run clear @s iron_ore 1
execute if items entity @s hotbar.* iron_ore run give @s iron_ingot 1
execute if items entity @s hotbar.* iron_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* iron_ore run title @s actionbar {"text":"鉄鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* iron_ore run clear @s iron_ore 1
execute if items entity @s inventory.* copper_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* copper_ore run title @s actionbar {"text":"銭鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* copper_ore run clear @s copper_ore 1
execute if items entity @s hotbar.* copper_ore run give @s copper_ingot 1
execute if items entity @s hotbar.* copper_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* copper_ore run title @s actionbar {"text":"銭鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* copper_ore run clear @s copper_ore 1
execute if items entity @s inventory.* gold_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* gold_ore run title @s actionbar {"text":"金鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* gold_ore run clear @s gold_ore 1
execute if items entity @s hotbar.* gold_ore run give @s gold_ingot 1
execute if items entity @s hotbar.* gold_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* gold_ore run title @s actionbar {"text":"金鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* gold_ore run clear @s gold_ore 1
execute if items entity @s inventory.* deepslate_iron_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* deepslate_iron_ore run title @s actionbar {"text":"深層鉄鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* deepslate_iron_ore run clear @s deepslate_iron_ore 1
execute if items entity @s hotbar.* deepslate_iron_ore run give @s iron_ingot 1
execute if items entity @s hotbar.* deepslate_iron_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* deepslate_iron_ore run title @s actionbar {"text":"深層鉄鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* deepslate_iron_ore run clear @s deepslate_iron_ore 1
execute if items entity @s inventory.* deepslate_copper_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* deepslate_copper_ore run title @s actionbar {"text":"深層銭鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* deepslate_copper_ore run clear @s deepslate_copper_ore 1
execute if items entity @s hotbar.* deepslate_copper_ore run give @s copper_ingot 1
execute if items entity @s hotbar.* deepslate_copper_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* deepslate_copper_ore run title @s actionbar {"text":"深層銭鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* deepslate_copper_ore run clear @s deepslate_copper_ore 1
execute if items entity @s inventory.* deepslate_gold_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* deepslate_gold_ore run title @s actionbar {"text":"深層金鉱石を焼きました","color":"gold"}
execute if items entity @s inventory.* deepslate_gold_ore run clear @s deepslate_gold_ore 1
execute if items entity @s hotbar.* deepslate_gold_ore run give @s gold_ingot 1
execute if items entity @s hotbar.* deepslate_gold_ore run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* deepslate_gold_ore run title @s actionbar {"text":"深層金鉱石を焼きました","color":"gold"}
execute if items entity @s hotbar.* deepslate_gold_ore run clear @s deepslate_gold_ore 1
execute if items entity @s inventory.* cactus run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* cactus run title @s actionbar {"text":"サボテンを焼きました","color":"gold"}
execute if items entity @s inventory.* cactus run clear @s cactus 1
execute if items entity @s hotbar.* cactus run give @s green_dye 1
execute if items entity @s hotbar.* cactus run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* cactus run title @s actionbar {"text":"サボテンを焼きました","color":"gold"}
execute if items entity @s hotbar.* cactus run clear @s cactus 1
execute if items entity @s inventory.* sand run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* sand run title @s actionbar {"text":"砂を焼きました","color":"gold"}
execute if items entity @s inventory.* sand run clear @s sand 1
execute if items entity @s hotbar.* sand run give @s glass 1
execute if items entity @s hotbar.* sand run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* sand run title @s actionbar {"text":"砂を焼きました","color":"gold"}
execute if items entity @s hotbar.* sand run clear @s sand 1
execute if items entity @s inventory.* red_sand run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* red_sand run title @s actionbar {"text":"赤砂を焼きました","color":"gold"}
execute if items entity @s inventory.* red_sand run clear @s red_sand 1
execute if items entity @s hotbar.* red_sand run give @s glass 1
execute if items entity @s hotbar.* red_sand run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* red_sand run title @s actionbar {"text":"赤砂を焼きました","color":"gold"}
execute if items entity @s hotbar.* red_sand run clear @s red_sand 1
execute if items entity @s inventory.* clay run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* clay run title @s actionbar {"text":"粘後を焼きました","color":"gold"}
execute if items entity @s inventory.* clay run clear @s clay 1
execute if items entity @s hotbar.* clay run give @s brick 1
execute if items entity @s hotbar.* clay run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* clay run title @s actionbar {"text":"粘後を焼きました","color":"gold"}
execute if items entity @s hotbar.* clay run clear @s clay 1
execute if items entity @s inventory.* wet_sponge run give @s sponge 1
execute if items entity @s inventory.* wet_sponge run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* wet_sponge run title @s actionbar {"text":"濋れたスポンジを焼きました","color":"gold"}
execute if items entity @s inventory.* wet_sponge run clear @s wet_sponge 1
execute if items entity @s hotbar.* wet_sponge run give @s sponge 1
execute if items entity @s hotbar.* wet_sponge run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* wet_sponge run title @s actionbar {"text":"濋れたスポンジを焼きました","color":"gold"}
execute if items entity @s hotbar.* wet_sponge run clear @s wet_sponge 1

# 原石
execute if items entity @s inventory.* raw_iron run give @s iron_ingot 1
execute if items entity @s inventory.* raw_iron run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* raw_iron run title @s actionbar {"text":"鉄の原石を焼きました","color":"gold"}
execute if items entity @s inventory.* raw_iron run clear @s raw_iron 1
execute if items entity @s hotbar.* raw_iron run give @s iron_ingot 1
execute if items entity @s hotbar.* raw_iron run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* raw_iron run title @s actionbar {"text":"鉄の原石を焼きました","color":"gold"}
execute if items entity @s hotbar.* raw_iron run clear @s raw_iron 1
execute if items entity @s inventory.* raw_copper run give @s copper_ingot 1
execute if items entity @s inventory.* raw_copper run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* raw_copper run title @s actionbar {"text":"銅の原石を焼きました","color":"gold"}
execute if items entity @s inventory.* raw_copper run clear @s raw_copper 1
execute if items entity @s hotbar.* raw_copper run give @s copper_ingot 1
execute if items entity @s hotbar.* raw_copper run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* raw_copper run title @s actionbar {"text":"銅の原石を焼きました","color":"gold"}
execute if items entity @s hotbar.* raw_copper run clear @s raw_copper 1
execute if items entity @s inventory.* raw_gold run give @s gold_ingot 1
execute if items entity @s inventory.* raw_gold run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s inventory.* raw_gold run title @s actionbar {"text":"金の原石を焼きました","color":"gold"}
execute if items entity @s inventory.* raw_gold run clear @s raw_gold 1
execute if items entity @s hotbar.* raw_gold run give @s gold_ingot 1
execute if items entity @s hotbar.* raw_gold run playsound item.firecharge.use master @s ~ ~ ~ 0.05 1
execute if items entity @s hotbar.* raw_gold run title @s actionbar {"text":"金の原石を焼きました","color":"gold"}
execute if items entity @s hotbar.* raw_gold run clear @s raw_gold 1

