execute as @s if entity @s[type=arrow] run setblock ~ ~1 ~ water
kill @s[type=arrow]