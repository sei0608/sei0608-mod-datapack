scoreboard objectives add swap_timer dummy
scoreboard objectives add global_vars dummy

# グローバルIDの初期化
execute unless score #current global_vars matches ..2147483647 run scoreboard players set #current global_vars 1

gamerule immediate_respawn true

tellraw @a {text:"reload",click_event:{action:"run_command",command:reload}}