advancement grant @s only inc_enchant:kazane
advancement grant @s only inc_enchant:borrow_armor
