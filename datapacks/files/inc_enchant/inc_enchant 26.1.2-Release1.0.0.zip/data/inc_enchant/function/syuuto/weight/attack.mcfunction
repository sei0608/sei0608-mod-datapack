attribute @s jump_strength base set 0
scoreboard players set @s jump 0

particle minecraft:raid_omen ~ ~ ~ 0.3 0.3 0.3 0.1 10