execute store result score @s fail run random value 1..5
execute unless score @s fail matches 1 run return fail
execute store result score @s syuuto.inventory run random value 0..36
tellraw @s "どこかのスロットが消された..."
item replace entity @s[scores={syuuto.inventory=0}] inventory.0 with air
item replace entity @s[scores={syuuto.inventory=1}] inventory.1 with air
item replace entity @s[scores={syuuto.inventory=2}] inventory.2 with air
item replace entity @s[scores={syuuto.inventory=3}] inventory.3 with air
item replace entity @s[scores={syuuto.inventory=4}] inventory.4 with air
item replace entity @s[scores={syuuto.inventory=5}] inventory.5 with air
item replace entity @s[scores={syuuto.inventory=6}] inventory.6 with air
item replace entity @s[scores={syuuto.inventory=7}] inventory.7 with air
item replace entity @s[scores={syuuto.inventory=8}] inventory.8 with air
item replace entity @s[scores={syuuto.inventory=9}] inventory.9 with air
item replace entity @s[scores={syuuto.inventory=10}] inventory.10 with air
item replace entity @s[scores={syuuto.inventory=11}] inventory.11 with air
item replace entity @s[scores={syuuto.inventory=12}] inventory.12 with air
item replace entity @s[scores={syuuto.inventory=13}] inventory.13 with air
item replace entity @s[scores={syuuto.inventory=14}] inventory.14 with air
item replace entity @s[scores={syuuto.inventory=15}] inventory.15 with air
item replace entity @s[scores={syuuto.inventory=16}] inventory.16 with air
item replace entity @s[scores={syuuto.inventory=17}] inventory.17 with air
item replace entity @s[scores={syuuto.inventory=18}] inventory.18 with air
item replace entity @s[scores={syuuto.inventory=19}] inventory.19 with air
item replace entity @s[scores={syuuto.inventory=20}] inventory.20 with air
item replace entity @s[scores={syuuto.inventory=21}] inventory.21 with air
item replace entity @s[scores={syuuto.inventory=22}] inventory.22 with air
item replace entity @s[scores={syuuto.inventory=23}] inventory.23 with air
item replace entity @s[scores={syuuto.inventory=24}] inventory.24 with air
item replace entity @s[scores={syuuto.inventory=25}] inventory.25 with air
item replace entity @s[scores={syuuto.inventory=26}] inventory.26 with air
item replace entity @s[scores={syuuto.inventory=27}] hotbar.0 with air
item replace entity @s[scores={syuuto.inventory=28}] hotbar.1 with air
item replace entity @s[scores={syuuto.inventory=29}] hotbar.2 with air
item replace entity @s[scores={syuuto.inventory=30}] hotbar.3 with air
item replace entity @s[scores={syuuto.inventory=31}] hotbar.4 with air
item replace entity @s[scores={syuuto.inventory=32}] hotbar.5 with air
item replace entity @s[scores={syuuto.inventory=33}] hotbar.6 with air
item replace entity @s[scores={syuuto.inventory=34}] hotbar.7 with air
item replace entity @s[scores={syuuto.inventory=35}] hotbar.8 with air
item replace entity @s[scores={syuuto.inventory=36}] weapon.offhand with air