
scoreboard players set @a[scores={totem.death=1..}] totem.count 0
scoreboard players set @a[scores={totem.death=1..}] totem.death 0
