
execute unless entity @s[scores={totem.count=..2147483647}] run scoreboard players set @s totem.count 0
execute unless entity @s[scores={totem.time=..2147483647}] run scoreboard players set @s totem.time 0

effect give @s[scores={totem.count=..0,health=..6}] instant_health 1 100 true
tellraw @s[scores={totem.count=..0,health=..6}] "§4「不屈の意志」§r発動!!"
execute as @s[scores={totem.count=..0,health=..6}] run playsound item.totem.use master @a ~ ~ ~
scoreboard players add @s[scores={totem.count=..0,health=..6}] totem.count 1


execute as @s[scores={totem.death=1..,totem.time=0}] run schedule function inc_enchant:syuuto/totem.reset 5s
scoreboard players add @s[scores={totem.death=1..}] totem.time 1
scoreboard players reset @s[scores={totem.time=200..}] totem.time