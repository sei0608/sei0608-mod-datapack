
scoreboard players add @s[predicate=inc_enchant:sneaking] healing_field 1

execute if score @s healing_field matches 15.. if predicate inc_enchant:sneaking run effect give @s regeneration 10 0 true
scoreboard players reset @s[scores={healing_field=15..},predicate=inc_enchant:sneaking] healing_field
scoreboard players reset @s[predicate=!inc_enchant:sneaking] healing_field
execute unless predicate inc_enchant:sneaking run effect clear @s[scores={healing_field=1..}] regeneration
