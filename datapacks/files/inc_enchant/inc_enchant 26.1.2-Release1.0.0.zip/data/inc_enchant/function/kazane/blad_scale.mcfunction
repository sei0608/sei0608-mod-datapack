scoreboard players set @s heal 3
effect give @s regeneration 1 5