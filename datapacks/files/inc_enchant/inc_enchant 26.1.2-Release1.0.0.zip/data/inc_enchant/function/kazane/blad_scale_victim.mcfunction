# 攻撃された相手の体力が0以下、かつ既に死亡扱い（is_aliveではない）の場合に実行
execute if entity @s[nbt={Health:0.0f}] on attacker run function inc_enchant:kazane/blad_scale