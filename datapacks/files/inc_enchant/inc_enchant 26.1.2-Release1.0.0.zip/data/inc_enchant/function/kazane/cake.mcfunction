scoreboard players add @s cake 1
give @s[scores={cake=6000..}] cake
tellraw @s[scores={cake=6000..}] "へいおまち！"
scoreboard players reset @s[scores={cake=6000..}] cake